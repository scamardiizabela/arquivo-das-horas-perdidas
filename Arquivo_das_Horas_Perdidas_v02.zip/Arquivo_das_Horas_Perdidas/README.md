# O Arquivo das Horas Perdidas

Protótipo inicial em Godot 4.2+ do capítulo 1, A Carta Impossível.

## Como executar
1. Instale Godot 4.2 ou superior.
2. Abra o Godot, escolha **Importar**, selecione `project.godot`.
3. Clique em **Executar projeto** (F6/F5).
4. Explore a plataforma, a sala de espera e a bilheteria.

## Solução de teste (spoiler)
- Examine o banco na plataforma e a tábua na sala de espera.
- Volte à plataforma e conserte o relógio.
- Leia a passagem e vá à bilheteria.
- Abra o armário com a sequência estrela, lua, sol.

## Escopo atual
- Três ambientes navegáveis por botões
- Inventário persistente
- Dois objetos coletáveis e mecanismo de combinação contextual
- Um puzzle de discos giratórios
- Salvamento local e reinício
- Interface temporária, sem arte final, áudio ou animações

## Próxima etapa
- Substituir interface temporária por cenários ilustrados com hotspots.
- Criar estados de aproximação e animações de interação.
- Implementar mapa, diário, sistema de dicas e pistas progressivas.
- Preparar exportação Android/iOS e testar em dispositivos reais.

## Observações
O projeto não foi executado em Godot neste ambiente. Deve ser aberto e validado no editor antes de distribuição. Exportar para iOS requer o fluxo de compilação e assinatura da Apple em macOS/Xcode.
